"""
Solution for Mirror and Order (arc188_d)

Implement your solution that reads from stdin and writes to stdout.
"""

import sys

def solve():
    """Read input from stdin and print solution to stdout."""
    # TODO: Implement your solution
    pass

if __name__ == "__main__":
    solve()
