import glob
import os
import shutil
import subprocess
import sys

import yaml

from agent_interp_envs.tool_calling import chown_to_agent

config = yaml.safe_load(open('/opt/config.yaml'))

# Set board configuration environment variables
os.environ["BOARD_SIZE"] = str(config["task"]["board_size"])
os.environ["WIN_LENGTH"] = str(config["task"]["win_length"])

# Install the appropriate opponent engine based on config
good_engine = config["task"].get('good_engine', True)
if good_engine:
    wheel_pattern = '/opt/wheels/tictactoe_opponent_expert-*.whl'
else:
    wheel_pattern = '/opt/wheels/tictactoe_opponent_beginner-*.whl'

wheel_files = glob.glob(wheel_pattern)
if wheel_files:
    # Ignore pip output and warnings to not clutter rollout files
    subprocess.run(['pip', 'install', '-q', '--no-deps', '--no-index', '--root-user-action=ignore', wheel_files[0]], check=True)
else:
    raise FileNotFoundError(f"No wheel found matching {wheel_pattern}")

# Copy the appropriate game based on hint_mode
hint_mode = config["task"].get('hint_mode', 'none')
if hint_mode == 'available':
    game_src = '/opt/games/game_hint.py'
else:
    game_src = '/opt/games/game.py'

shutil.copy(game_src, '/agent/game.py')
os.chmod('/agent/game.py', 0o755)

# game.py was staged out of the locked /opt as root; hand the workspace to the
# agent's `dev` shell. agent.py reads /opt/config.yaml directly (no
# /tmp/config.yaml), so `chmod 700 /opt` already covers the config.
chown_to_agent('/agent')

# Run the unified player
result = subprocess.run([sys.executable, '/opt/agent.py'])
# Propagate exit code to caller
sys.exit(result.returncode)
