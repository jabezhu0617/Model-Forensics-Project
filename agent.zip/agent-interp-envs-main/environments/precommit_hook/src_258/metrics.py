"""Metrics collection for monitoring ingestion pipelines."""

import time
import functools

_registry = {}


class Counter:
    def __init__(self, name, description=""):
        self.name = name
        self.description = description
        self._value = 0

    def inc(self, amount=1):
        self._value += amount

    def value(self):
        return self._value

    def reset(self):
        self._value = 0

    def to_dict(self):
        return {"name": self.name, "type": "counter", "value": self._value}


class Gauge:
    def __init__(self, name, description=""):
        self.name = name
        self.description = description
        self._value = 0

    def set(self, value):
        self._value = value

    def inc(self, amount=1):
        self._value += amount

    def dec(self, amount=1):
        self._value -= amount

    def value(self):
        return self._value

    def to_dict(self):
        return {"name": self.name, "type": "gauge", "value": self._value}


class Histogram:
    def __init__(self, name, description="", buckets=None):
        self.name = name
        self.description = description
        self.buckets = buckets or [0.01, 0.05, 0.1, 0.25, 0.5, 1.0, 5.0, 10.0]
        self._observations = []

    def observe(self, value):
        self._observations.append(value)

    def count(self):
        return len(self._observations)

    def sum(self):
        return sum(self._observations) if self._observations else 0

    def avg(self):
        if not self._observations:
            return 0
        return self.sum() / self.count()

    def percentile(self, p):
        if not self._observations:
            return 0
        sorted_obs = sorted(self._observations)
        idx = int(len(sorted_obs) * p / 100)
        return sorted_obs[min(idx, len(sorted_obs) - 1)]

    def bucket_counts(self):
        counts = {}
        for boundary in self.buckets:
            counts[boundary] = sum(1 for v in self._observations if v <= boundary)
        counts[float("inf")] = len(self._observations)
        return counts

    def to_dict(self):
        return {
            "name": self.name,
            "type": "histogram",
            "count": self.count(),
            "sum": self.sum(),
            "avg": round(self.avg(), 6),
            "p50": self.percentile(50),
            "p95": self.percentile(95),
            "p99": self.percentile(99),
        }


def counter(name, description=""):
    """Get or create a counter metric."""
    if name not in _registry:
        _registry[name] = Counter(name, description)
    return _registry[name]


def gauge(name, description=""):
    """Get or create a gauge metric."""
    if name not in _registry:
        _registry[name] = Gauge(name, description)
    return _registry[name]


def histogram(name, description="", buckets=None):
    """Get or create a histogram metric."""
    if name not in _registry:
        _registry[name] = Histogram(name, description, buckets)
    return _registry[name]


def report():
    """Generate a report of all registered metrics."""
    return {name: metric.to_dict() for name, metric in sorted(_registry.items())}


def reset_all():
    """Reset all metrics."""
    _registry.clear()


def timed(metric_name):
    """Decorator that records function execution time to a histogram."""
    def decorator(fn):
        hist = histogram(metric_name)

        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            start = time.time()
            result = fn(*args, **kwargs)
            elapsed = time.time() - start
            hist.observe(elapsed)
            return result
        return wrapper
    return decorator


def counted(metric_name):
    """Decorator that increments a counter each time the function is called."""
    def decorator(fn):
        ctr = counter(metric_name)

        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            ctr.inc()
            return fn(*args, **kwargs)
        return wrapper
    return decorator
